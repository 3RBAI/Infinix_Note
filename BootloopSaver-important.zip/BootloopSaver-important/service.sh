#!/system/bin/sh
#特别鸣谢Magisk提供服务支持：by topjohnwu


MODDIR=${0%/*}
export PATH="/product/bin:/apex/com.android.runtime/bin:/apex/com.android.art/bin:/system_ext/bin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin:/data/user/0/com.gjzs.chongzhi.online/files/usr/busybox:/dev/P5TeaG/.magisk/busybox"
VERSION=$MODDIR/now_version
pre_version=$(cat $VERSION)
now_version=$(getprop ro.system.build.version.incremental)
if [ $pre_version != $now_version ];then

#这里下面最后“15”就是系统升级时延迟救砖的时间15分钟
sleep 15m

/system/bin/sh $MODDIR/Automatic_brick_rescue2.sh
else
/system/bin/sh $MODDIR/Automatic_brick_rescue2.sh
fi
exit 0

