#掛載選項
SKIPMOUNT=false
#如果需要加載system.prop，請設置為true
PROPFILE=true
#如果需要post-fs-data腳本，則設置為true
POSTFSDATA=true
#如果需要service服務腳本，請設置為true
LATESTARTSERVICE=true
====================================================================

REPLACE="
/system/app/XiaomiServiceFramework
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"
REPLACE="
"
##########################################################################################
print_modname() {
  ui_print "*******************************"
  ui_print "$pounds"
  ui_print " 支持面具MAGISK19.3+"
  echo $(getprop ro.system.build.version.incremental)>/data/adb/modules_update/Automatic_brick_rescue/now_version
  ui_print " 当前系统版本：$(getprop ro.system.build.version.incremental)"
  ui_print " $MODNAME "
  ui_print " 奋斗的小青年修改 原作者：Han　情非得已c"
  ui_print " 首发地址：公众号：有效玩机！！！"
  ui_print " "
  ui_print " 在双防，防冻版，OTA版之后再次更新的版本，新增白名单功能 "
  ui_print " 若反复重启3次或第二屏等待1.5分钟（每次OTA升级系统后将延长至15分钟）后无法开机，"
  ui_print " 将直接进入自动救砖操作，禁用所有模块并开机！"
  ui_print " 如果开机失败会进入第4次重启，移出所有冻结的APP以解救无法开机的情况！"
  ui_print " 特别感谢酷安靓仔，@淘宝店小二提供的OTA相关代码"
  ui_print " 通过酷友@Rwsk_魂，已经获得原作者授权！！！"
  ui_print " "
  ui_print "******************************"
}



on_install() {
  ui_print "- 刷入通用模块文件"
  unzip -o "$ZIPFILE" 'Automatic_brick_rescue.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'Automatic_brick_rescue2.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'post-fs-data.sh' -d $MODPATH >&2   
  unzip -o "$ZIPFILE" 'service.sh' -d $MODPATH >&2   
  unzip -o "$ZIPFILE" 'module.prop.bak' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'uninstall.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" '白名单.conf' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}